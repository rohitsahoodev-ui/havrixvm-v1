# Havrix VM - VPS Management Panel

## Version 1.0.0

A complete production-ready VPS Management Panel built with Python Flask.

## Features

### User Features
- User Authentication (Login/Register)
- Dashboard with VPS Statistics
- VPS Management (Create, View, Delete)
- VPS Power Controls (Start, Stop, Restart, Rebuild)
- Browser-based Console
- SSH Access Details
- SSHX Session Integration
- TMATE Session Integration
- Support Ticket System
- User Profile Management
- Password Change

### Admin Features
- Admin Dashboard with System Stats
- User Management (Create, Edit, Delete, Suspend, Unsuspend)
- VPS Management (Create, Edit, Delete, Suspend, Unsuspend)
- VPS Power Controls for Admin
- System Settings Configuration
- Support Ticket Management

### Security Features
- Login Rate Limiting
- IP Blocking
- Session Protection
- CSRF Protection
- Security Headers
- Request Validation
- XSS Protection

## Tech Stack

- **Backend**: Python Flask
- **Frontend**: HTML, CSS, Vanilla JavaScript
- **Database**: SQLite
- **Authentication**: Flask-Login, Bcrypt
- **Security**: CSRF Protection, XSS Protection, Rate Limiting

## Installation

### Prerequisites
- Python 3.8+
- pip

### Step 1: Clone the Repository
```bash
git clone <repository-url>
cd havrix-vm