import os
import logging
from datetime import datetime
from flask import Flask, render_template, request, session, g, jsonify
from flask_login import LoginManager, current_user
from flask_wtf.csrf import CSRFProtect
from werkzeug.middleware.proxy_fix import ProxyFix
from config import get_config
from database import db
from database import init_db
from middleware.security import SecurityMiddleware

# Initialize extensions
login_manager = LoginManager()
csrf = CSRFProtect()

def create_app(config_name=None):
    """Application factory function"""
    app = Flask(__name__, 
                template_folder='templates',
                static_folder='static')
    
    # Load configuration
    if config_name is None:
        config_name = os.environ.get('FLASK_ENV', 'default')
    app.config.from_object(get_config())
    
    # Initialize extensions
    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)
    
    # Configure login manager
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please log in to access this page.'
    login_manager.login_message_category = 'warning'
    login_manager.session_protection = 'strong'
    
    # Apply security middleware
    app.wsgi_app = SecurityMiddleware(app.wsgi_app)
    
    # Set up proxy fix for reverse proxy
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)
    
    # Configure logging
    setup_logging(app)
    
    # Register blueprints
    from routes.auth import auth_bp
    from routes.user import user_bp
    from routes.server import server_bp
    from routes.support import support_bp
    from routes.admin import admin_bp
    
    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(user_bp, url_prefix='/user')
    app.register_blueprint(server_bp, url_prefix='/server')
    app.register_blueprint(support_bp, url_prefix='/support')
    app.register_blueprint(admin_bp, url_prefix='/admin')
    
    # Initialize database with default data
    init_db(app)
    
    # Register error handlers
    register_error_handlers(app)
    
    # Register context processors
    register_context_processors(app)
    
    return app

def setup_logging(app):
    """Configure application logging"""
    if not app.debug:
        # Set up file handler
        log_file = app.config.get('LOG_FILE')
        if log_file:
            os.makedirs(os.path.dirname(log_file), exist_ok=True)
            file_handler = logging.FileHandler(log_file)
            file_handler.setLevel(logging.INFO)
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            file_handler.setFormatter(formatter)
            app.logger.addHandler(file_handler)
        
        # Set up console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.WARNING)
        app.logger.addHandler(console_handler)
    
    app.logger.setLevel(app.config.get('LOG_LEVEL', 'INFO'))

def register_error_handlers(app):
    """Register custom error handlers"""
    
    @app.errorhandler(404)
    def not_found_error(error):
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'error': 'Resource not found'}), 404
        return render_template('error.html', 
                             error_code=404, 
                             error_message='Page not found'), 404
    
    @app.errorhandler(403)
    def forbidden_error(error):
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'error': 'Access forbidden'}), 403
        return render_template('error.html', 
                             error_code=403, 
                             error_message='Access forbidden'), 403
    
    @app.errorhandler(500)
    def internal_error(error):
        app.logger.error(f'Internal server error: {error}')
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'error': 'Internal server error'}), 500
        return render_template('error.html', 
                             error_code=500, 
                             error_message='Internal server error'), 500
    
    @app.errorhandler(429)
    def ratelimit_error(error):
        return jsonify({'error': 'Too many requests. Please try again later.'}), 429

def register_context_processors(app):
    """Register template context processors"""
    
    @app.context_processor
    def inject_user():
        return {
            'current_user': current_user,
            'now': datetime.now()
        }
    
    @app.context_processor
    def inject_config():
        return {
            'app_name': 'Havrix VM',
            'app_version': '1.0.0'
        }

@login_manager.user_loader
def load_user(user_id):
    """Load user for Flask-Login"""
    from models.user import User
    return User.query.get(int(user_id))

# Create application instance
app = create_app()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=app.config.get('DEBUG', False))