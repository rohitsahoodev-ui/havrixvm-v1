import os
import secrets

class Config:
    """Base configuration class"""
    
    # Application settings
    SECRET_KEY = os.environ.get('SECRET_KEY') or secrets.token_hex(32)
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    PERMANENT_SESSION_LIFETIME = 86400  # 24 hours
    
    # Database
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///database/database.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_size': 10,
        'pool_recycle': 3600,
        'pool_pre_ping': True,
    }
    
    # Security settings
    RATE_LIMIT_ENABLED = True
    RATE_LIMIT_REQUESTS = 5
    RATE_LIMIT_PERIOD = 60  # seconds
    MAX_LOGIN_ATTEMPTS = 5
    LOGIN_TIMEOUT = 900  # 15 minutes
    
    # IP Blocking
    IP_BLOCK_THRESHOLD = 10
    IP_BLOCK_DURATION = 3600  # 1 hour
    
    # Session protection
    SESSION_PROTECTION = True
    SESSION_FINGERPRINT = True
    
    # CSRF
    CSRF_ENABLED = True
    CSRF_SECRET = os.environ.get('CSRF_SECRET') or secrets.token_hex(32)
    CSRF_TIME_LIMIT = 3600  # 1 hour
    
    # Security headers
    SECURITY_HEADERS = {
        'X-Content-Type-Options': 'nosniff',
        'X-Frame-Options': 'DENY',
        'X-XSS-Protection': '1; mode=block',
        'Referrer-Policy': 'strict-origin-when-cross-origin',
        'Permissions-Policy': 'geolocation=(), microphone=(), camera=()'
    }
    
    # Application paths
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    TEMPLATE_FOLDER = os.path.join(BASE_DIR, 'templates')
    STATIC_FOLDER = os.path.join(BASE_DIR, 'static')
    DATABASE_FOLDER = os.path.join(BASE_DIR, 'database')
    
    # Ensure database directory exists
    os.makedirs(DATABASE_FOLDER, exist_ok=True)
    
    # VPS Configuration
    VPS_RESOURCES = {
        'cpu_cores': 4,
        'ram_min': 512,  # MB
        'ram_max': 16384,  # MB
        'disk_min': 10,  # GB
        'disk_max': 1000,  # GB
    }
    
    # Supported Operating Systems
    SUPPORTED_OS = [
        'Ubuntu 22.04 LTS',
        'Ubuntu 20.04 LTS',
        'Debian 12',
        'Debian 11',
        'CentOS 9 Stream',
        'Rocky Linux 9',
        'AlmaLinux 9',
        'Fedora 38',
    ]
    
    # SSH Configuration
    SSH_DEFAULT_PORT = 22
    SSH_KEY_LENGTH = 2048
    
    # Console settings
    CONSOLE_BUFFER_SIZE = 10000
    CONSOLE_HEARTBEAT_INTERVAL = 30  # seconds
    
    # SSHX settings
    SSHX_ENABLED = True
    SSHX_SESSION_TIMEOUT = 3600  # 1 hour
    SSHX_BASE_URL = os.environ.get('SSHX_BASE_URL', 'https://sshx.example.com')
    
    # TMATE settings
    TMATE_ENABLED = True
    TMATE_SESSION_TIMEOUT = 7200  # 2 hours
    TMATE_BASE_URL = os.environ.get('TMATE_BASE_URL', 'https://tmate.io')
    
    # Pagination
    ITEMS_PER_PAGE = 25
    
    # Logging
    LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')
    LOG_FILE = os.path.join(BASE_DIR, 'logs', 'havrix.log')
    
    # Ensure logs directory exists
    os.makedirs(os.path.join(BASE_DIR, 'logs'), exist_ok=True)
    
    # Admin configuration
    ADMIN_ROLE = 'admin'
    USER_ROLE = 'user'
    
    # Default Admin Credentials (can be changed via environment variables)
    DEFAULT_ADMIN_USERNAME = os.environ.get('DEFAULT_ADMIN_USERNAME', 'admin')
    DEFAULT_ADMIN_EMAIL = os.environ.get('DEFAULT_ADMIN_EMAIL', 'admin@havrix.com')
    DEFAULT_ADMIN_PASSWORD = os.environ.get('DEFAULT_ADMIN_PASSWORD', 'admin123')
    ALLOW_ADMIN_PASSWORD_CHANGE = os.environ.get('ALLOW_ADMIN_PASSWORD_CHANGE', 'true').lower() == 'true'
    
    # Ticket statuses
    TICKET_STATUSES = ['open', 'in_progress', 'closed']
    TICKET_PRIORITIES = ['low', 'medium', 'high', 'critical']
    
    # VPS statuses
    VPS_STATUSES = ['running', 'stopped', 'suspended', 'creating', 'deleting', 'rebuilding']
    
    # Session keys
    SESSION_USER_ID = 'user_id'
    SESSION_USERNAME = 'username'
    SESSION_ROLE = 'role'
    SESSION_FINGERPRINT = 'fingerprint'
    SESSION_CSRF_TOKEN = 'csrf_token'
    SESSION_LAST_ACTIVITY = 'last_activity'

class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True
    TESTING = False
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    SESSION_COOKIE_SECURE = False
    LOG_LEVEL = 'DEBUG'

class ProductionConfig(Config):
    """Production configuration"""
    DEBUG = False
    TESTING = False
    SECRET_KEY = os.environ.get('SECRET_KEY')
    SESSION_COOKIE_SECURE = True
    LOG_LEVEL = 'INFO'
    
    # Stricter security in production
    RATE_LIMIT_REQUESTS = 3
    IP_BLOCK_THRESHOLD = 5
    
class TestingConfig(Config):
    """Testing configuration"""
    TESTING = True
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///database/test.db'
    SESSION_COOKIE_SECURE = False
    RATE_LIMIT_ENABLED = False

# Configuration dictionary
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}

def get_config():
    """Get configuration based on environment"""
    env = os.environ.get('FLASK_ENV', 'default')
    return config.get(env, config['default'])()