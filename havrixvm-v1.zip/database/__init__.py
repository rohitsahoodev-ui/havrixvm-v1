from flask_sqlalchemy import SQLAlchemy
import os

# Simple database instance
db = SQLAlchemy()

def init_db(app):
    """Initialize database"""
    # Ensure database directory exists
    db_dir = os.path.join(app.root_path, 'database')
    os.makedirs(db_dir, exist_ok=True)
    
    db.init_app(app)
    with app.app_context():
        db.create_all()
        print("✅ Database initialized")

def get_db():
    return db