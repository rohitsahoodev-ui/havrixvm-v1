from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from config import get_config

db = SQLAlchemy()

def init_db(app):
    """Initialize database with tables and default data"""
    db.init_app(app)
    
    with app.app_context():
        # Create all tables
        db.create_all()
        
        # Create default admin user if not exists
        create_default_admin()

def create_default_admin():
    """Create default admin user if no admin exists"""
    from models.user import User
    config = get_config()
    
    admin = User.query.filter_by(role='admin').first()
    if not admin:
        admin_user = User(
            username=config.DEFAULT_ADMIN_USERNAME,
            email=config.DEFAULT_ADMIN_EMAIL,
            password=config.DEFAULT_ADMIN_PASSWORD,
            role='admin',
            is_active=True,
            is_verified=True
        )
        db.session.add(admin_user)
        db.session.commit()
        print(f'Default admin user created: {config.DEFAULT_ADMIN_USERNAME} / {config.DEFAULT_ADMIN_PASSWORD}')
        print('You can change admin password in user profile after login.')

def get_db():
    """Get database instance"""
    return db