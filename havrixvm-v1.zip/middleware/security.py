import time
import hashlib
import json
from datetime import datetime, timedelta
from collections import defaultdict
from flask import request, session, g, abort, jsonify, current_app
from werkzeug.middleware.base import WSGIRequestHandler
import re

class SecurityMiddleware:
    """Security middleware for protecting against common web vulnerabilities"""
    
    def __init__(self, app):
        self.app = app
        self.ip_attempts = defaultdict(list)
        self.blocked_ips = {}
        self.rate_limits = defaultdict(list)
        
    def __call__(self, environ, start_response):
        """Process the request through security checks"""
        request = self.get_request(environ)
        
        # Get client IP
        client_ip = self.get_client_ip(environ)
        g.client_ip = client_ip
        
        # Check if IP is blocked
        if self.is_ip_blocked(client_ip):
            start_response('403 Forbidden', [('Content-Type', 'text/plain')])
            return [b'Access denied: Your IP has been blocked due to suspicious activity']
        
        # Apply rate limiting
        if not self.check_rate_limit(client_ip, request.path):
            start_response('429 Too Many Requests', [('Content-Type', 'text/plain')])
            return [b'Too many requests. Please try again later.']
        
        # Apply CSRF protection for unsafe methods
        if request.method in ['POST', 'PUT', 'DELETE', 'PATCH']:
            if not self.check_csrf(request):
                start_response('403 Forbidden', [('Content-Type', 'text/plain')])
                return [b'CSRF token validation failed']
        
        # Apply XSS protection
        if not self.check_xss_protection(request):
            start_response('403 Forbidden', [('Content-Type', 'text/plain')])
            return [b'Suspicious input detected']
        
        # Process the request
        response = self.app(environ, start_response)
        
        # Add security headers
        self.add_security_headers(start_response, response)
        
        # Update session protection
        self.update_session_protection()
        
        return response
    
    def get_request(self, environ):
        """Get request object from environment"""
        class Request:
            def __init__(self, environ):
                self.method = environ.get('REQUEST_METHOD', 'GET')
                self.path = environ.get('PATH_INFO', '/')
                self.headers = self.parse_headers(environ)
                self.args = self.parse_query_string(environ)
                self.form = self.parse_form_data(environ)
                self.json = self.parse_json(environ)
            
            def parse_headers(self, environ):
                headers = {}
                for key, value in environ.items():
                    if key.startswith('HTTP_'):
                        header_name = key[5:].replace('_', '-').title()
                        headers[header_name] = value
                return headers
            
            def parse_query_string(self, environ):
                from urllib.parse import parse_qs
                qs = environ.get('QUERY_STRING', '')
                return {k: v[0] if len(v) == 1 else v for k, v in parse_qs(qs).items()}
            
            def parse_form_data(self, environ):
                if environ.get('CONTENT_TYPE', '').startswith('application/x-www-form-urlencoded'):
                    from urllib.parse import parse_qs
                    content_length = int(environ.get('CONTENT_LENGTH', 0))
                    if content_length > 0:
                        body = environ['wsgi.input'].read(content_length)
                        return {k: v[0] if len(v) == 1 else v for k, v in parse_qs(body.decode()).items()}
                return {}
            
            def parse_json(self, environ):
                if environ.get('CONTENT_TYPE', '').startswith('application/json'):
                    content_length = int(environ.get('CONTENT_LENGTH', 0))
                    if content_length > 0:
                        body = environ['wsgi.input'].read(content_length)
                        try:
                            return json.loads(body.decode())
                        except:
                            return None
                return None
        
        return Request(environ)
    
    def get_client_ip(self, environ):
        """Get client IP address from environment"""
        # Check for forwarded IP (proxy)
        forwarded = environ.get('HTTP_X_FORWARDED_FOR')
        if forwarded:
            return forwarded.split(',')[0].strip()
        
        # Check for real IP
        real_ip = environ.get('HTTP_X_REAL_IP')
        if real_ip:
            return real_ip
        
        # Fallback to remote address
        return environ.get('REMOTE_ADDR', '0.0.0.0')
    
    def is_ip_blocked(self, ip):
        """Check if IP is currently blocked"""
        if ip in self.blocked_ips:
            block_time, attempts = self.blocked_ips[ip]
            if time.time() - block_time < 3600:  # 1 hour block
                return True
            else:
                del self.blocked_ips[ip]
        return False
    
    def check_rate_limit(self, ip, path):
        """Check if request exceeds rate limit"""
        current_app_config = current_app.config if hasattr(current_app, 'config') else {}
        if not current_app_config.get('RATE_LIMIT_ENABLED', True):
            return True
        
        key = f"{ip}:{path}"
        now = time.time()
        limit = current_app_config.get('RATE_LIMIT_REQUESTS', 5)
        period = current_app_config.get('RATE_LIMIT_PERIOD', 60)
        
        # Clean old requests
        self.rate_limits[key] = [t for t in self.rate_limits.get(key, []) if now - t < period]
        
        # Check limit
        if len(self.rate_limits.get(key, [])) >= limit:
            # Block IP if too many violations
            if ip in self.blocked_ips:
                self.blocked_ips[ip] = (time.time(), self.blocked_ips[ip][1] + 1)
            else:
                self.blocked_ips[ip] = (time.time(), 1)
            return False
        
        # Add request
        self.rate_limits[key].append(now)
        return True
    
    def check_csrf(self, request):
        """Validate CSRF token"""
        # Skip CSRF for API endpoints with API keys or simple GET requests
        if request.path.startswith('/auth/') and request.method == 'POST':
            # Allow login/register without CSRF
            return True
        
        if request.path.startswith('/admin/') and request.headers.get('X-API-Key'):
            return True
        
        token = request.headers.get('X-CSRF-Token') or request.form.get('csrf_token')
        session_token = session.get('csrf_token')
        
        if not token or not session_token:
            return False
        
        # Validate token
        return token == session_token
    
    def check_xss_protection(self, request):
        """Check for potential XSS in request data"""
        # Check query parameters
        for key, value in request.args.items():
            if self.contains_xss_pattern(value):
                current_app.logger.warning(f'XSS attempt detected in query param {key}')
                return False
        
        # Check form data
        for key, value in request.form.items():
            if self.contains_xss_pattern(value):
                current_app.logger.warning(f'XSS attempt detected in form field {key}')
                return False
        
        # Check JSON data
        if request.json:
            for key, value in request.json.items():
                if isinstance(value, str) and self.contains_xss_pattern(value):
                    current_app.logger.warning(f'XSS attempt detected in JSON field {key}')
                    return False
        
        return True
    
    def contains_xss_pattern(self, value):
        """Check if value contains XSS patterns"""
        if not isinstance(value, str):
            return False
        
        # Common XSS patterns
        patterns = [
            r'<script[^>]*>.*?</script>',
            r'javascript:.*?',
            r'on\w+\s*=',  # event handlers
            r'<[^>]*on\w+\s*=[^>]*>',
            r'<iframe[^>]*>',
            r'<object[^>]*>',
            r'<embed[^>]*>',
            r'<applet[^>]*>',
            r'<link[^>]*>',
            r'<meta[^>]*>',
        ]
        
        # Check if any pattern matches
        for pattern in patterns:
            if re.search(pattern, value, re.IGNORECASE):
                return True
        
        # Check for HTML tags with attributes
        if re.search(r'<[^>]+>', value):
            return True
        
        return False
    
    def add_security_headers(self, start_response, response):
        """Add security headers to response"""
        headers = {
            'X-Content-Type-Options': 'nosniff',
            'X-Frame-Options': 'DENY',
            'X-XSS-Protection': '1; mode=block',
            'Referrer-Policy': 'strict-origin-when-cross-origin',
            'Permissions-Policy': 'geolocation=(), microphone=(), camera=()',
            'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data:;",
            'Strict-Transport-Security': 'max-age=31536000; includeSubDomains' if current_app.config.get('SESSION_COOKIE_SECURE', False) else ''
        }
        
        # Add headers to response
        if hasattr(response, 'headers'):
            for key, value in headers.items():
                if value:
                    response.headers[key] = value
    
    def update_session_protection(self):
        """Update session protection data"""
        if current_app.config.get('SESSION_PROTECTION', True) and 'user_id' in session:
            # Update session fingerprint
            fingerprint = self.generate_session_fingerprint()
            session['fingerprint'] = fingerprint
            session['last_activity'] = time.time()
    
    def generate_session_fingerprint(self):
        """Generate session fingerprint"""
        user_agent = request.headers.get('User-Agent', '')
        accept_language = request.headers.get('Accept-Language', '')
        
        # Combine user agent and accept language to create fingerprint
        fingerprint_data = f"{user_agent}|{accept_language}"
        return hashlib.sha256(fingerprint_data.encode()).hexdigest()
    
    def validate_session_fingerprint(self):
        """Validate session fingerprint"""
        if not current_app.config.get('SESSION_PROTECTION', True):
            return True
        
        if 'fingerprint' not in session:
            return False
        
        expected = self.generate_session_fingerprint()
        return session['fingerprint'] == expected