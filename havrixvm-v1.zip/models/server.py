from database import db
from datetime import datetime
import secrets
import string

class Server(db.Model):
    """Server/VPS model for managing virtual machines"""
    __tablename__ = 'servers'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(20), default='stopped')  # running, stopped, suspended, creating, deleting, rebuilding
    node = db.Column(db.String(50), default='node1')
    
    # Resources
    cpu_cores = db.Column(db.Integer, default=1)
    ram_mb = db.Column(db.Integer, default=1024)  # MB
    disk_gb = db.Column(db.Integer, default=20)  # GB
    
    # Network
    ipv4 = db.Column(db.String(15))
    ipv6 = db.Column(db.String(45))
    hostname = db.Column(db.String(100))
    
    # System
    os_type = db.Column(db.String(50))
    os_version = db.Column(db.String(50))
    os_image = db.Column(db.String(100))
    
    # SSH
    ssh_port = db.Column(db.Integer, default=22)
    ssh_username = db.Column(db.String(50), default='root')
    ssh_password = db.Column(db.String(255))  # Encrypted
    
    # Console
    console_port = db.Column(db.Integer)
    console_enabled = db.Column(db.Boolean, default=True)
    
    # SSHX
    sshx_session_id = db.Column(db.String(100))
    sshx_link = db.Column(db.String(255))
    sshx_created_at = db.Column(db.DateTime)
    sshx_expires_at = db.Column(db.DateTime)
    
    # TMATE
    tmate_session_id = db.Column(db.String(100))
    tmate_ssh_link = db.Column(db.String(255))
    tmate_web_link = db.Column(db.String(255))
    tmate_created_at = db.Column(db.DateTime)
    tmate_expires_at = db.Column(db.DateTime)
    
    # Metadata
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_started_at = db.Column(db.DateTime)
    last_stopped_at = db.Column(db.DateTime)
    
    def __init__(self, name, user_id, os_type='Ubuntu', os_version='22.04', 
                 cpu_cores=1, ram_mb=1024, disk_gb=20, node='node1'):
        self.name = name
        self.user_id = user_id
        self.os_type = os_type
        self.os_version = os_version
        self.os_image = f"{os_type}-{os_version}"
        self.cpu_cores = cpu_cores
        self.ram_mb = ram_mb
        self.disk_gb = disk_gb
        self.node = node
        self.status = 'stopped'
        self.hostname = self.generate_hostname()
        self.ipv4 = self.generate_ipv4()
        self.ipv6 = self.generate_ipv6()
        self.ssh_port = 22
        self.ssh_username = 'root'
        self.ssh_password = self.generate_ssh_password()
        self.console_port = self.generate_console_port()
    
    def generate_hostname(self):
        """Generate a random hostname"""
        return f"vps-{self.name.lower().replace(' ', '-')}-{secrets.token_hex(4)}"
    
    def generate_ipv4(self):
        """Generate a random IPv4 address (simulated)"""
        return f"10.0.{secrets.randbelow(255)}.{secrets.randbelow(255)}"
    
    def generate_ipv6(self):
        """Generate a random IPv6 address (simulated)"""
        hex_chars = string.hexdigits.lower()
        return ':'.join(''.join(secrets.choice(hex_chars) for _ in range(4)) for _ in range(8))
    
    def generate_ssh_password(self):
        """Generate a random SSH password"""
        characters = string.ascii_letters + string.digits + '!@#$%^&*'
        return ''.join(secrets.choice(characters) for _ in range(16))
    
    def generate_console_port(self):
        """Generate a random console port"""
        return secrets.randbelow(1000) + 5900
    
    def start(self):
        """Start the VPS"""
        if self.status == 'running':
            return False, 'VPS is already running'
        self.status = 'running'
        self.last_started_at = datetime.utcnow()
        return True, 'VPS started successfully'
    
    def stop(self):
        """Stop the VPS"""
        if self.status == 'stopped':
            return False, 'VPS is already stopped'
        self.status = 'stopped'
        self.last_stopped_at = datetime.utcnow()
        return True, 'VPS stopped successfully'
    
    def restart(self):
        """Restart the VPS"""
        if self.status == 'stopped':
            return False, 'Cannot restart stopped VPS'
        self.status = 'running'
        self.last_started_at = datetime.utcnow()
        return True, 'VPS restarted successfully'
    
    def rebuild(self):
        """Rebuild the VPS"""
        self.status = 'rebuilding'
        # In production, this would trigger a rebuild job
        self.status = 'stopped'
        return True, 'VPS rebuild initiated'
    
    def suspend(self):
        """Suspend the VPS"""
        if self.status == 'suspended':
            return False, 'VPS is already suspended'
        self.status = 'suspended'
        return True, 'VPS suspended successfully'
    
    def unsuspend(self):
        """Unsuspend the VPS"""
        if self.status != 'suspended':
            return False, 'VPS is not suspended'
        self.status = 'stopped'
        return True, 'VPS unsuspended successfully'
    
    def generate_sshx_session(self):
        """Generate SSHX session"""
        import secrets
        self.sshx_session_id = secrets.token_urlsafe(32)
        self.sshx_link = f"https://sshx.example/session/{self.sshx_session_id}"
        self.sshx_created_at = datetime.utcnow()
        self.sshx_expires_at = datetime.utcnow().replace(hour=datetime.utcnow().hour + 1)
        return self.sshx_link
    
    def generate_tmate_session(self):
        """Generate TMATE session"""
        import secrets
        session_token = secrets.token_urlsafe(16)
        self.tmate_session_id = session_token
        self.tmate_ssh_link = f"ssh user@tmate.io"
        self.tmate_web_link = f"https://tmate.io/t/{session_token}"
        self.tmate_created_at = datetime.utcnow()
        self.tmate_expires_at = datetime.utcnow().replace(hour=datetime.utcnow().hour + 2)
        return {
            'ssh_link': self.tmate_ssh_link,
            'web_link': self.tmate_web_link
        }
    
    def get_ssh_command(self):
        """Get SSH command for connecting to VPS"""
        return f"ssh {self.ssh_username}@{self.ipv4} -p {self.ssh_port}"
    
    def to_dict(self):
        """Convert server object to dictionary"""
        return {
            'id': self.id,
            'name': self.name,
            'status': self.status,
            'node': self.node,
            'cpu_cores': self.cpu_cores,
            'ram_mb': self.ram_mb,
            'disk_gb': self.disk_gb,
            'ipv4': self.ipv4,
            'ipv6': self.ipv6,
            'hostname': self.hostname,
            'os_type': self.os_type,
            'os_version': self.os_version,
            'os_image': self.os_image,
            'ssh_port': self.ssh_port,
            'ssh_username': self.ssh_username,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_started_at': self.last_started_at.isoformat() if self.last_started_at else None,
            'last_stopped_at': self.last_stopped_at.isoformat() if self.last_stopped_at else None,
            'sshx_link': self.sshx_link,
            'tmate_web_link': self.tmate_web_link,
            'console_port': self.console_port,
            'console_enabled': self.console_enabled
        }
    
    def __repr__(self):
        return f'<Server {self.name} ({self.status})>'