from database import db
from datetime import datetime

class Ticket(db.Model):
    """Support ticket model for managing user support requests"""
    __tablename__ = 'tickets'
    
    id = db.Column(db.Integer, primary_key=True)
    subject = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='open')  # open, in_progress, closed
    priority = db.Column(db.String(20), default='medium')  # low, medium, high, critical
    
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    admin_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    closed_at = db.Column(db.DateTime)
    
    # Relationships
    replies = db.relationship('TicketReply', backref='ticket', lazy=True, cascade='all, delete-orphan')
    
    def __init__(self, subject, message, user_id, priority='medium'):
        self.subject = subject
        self.message = message
        self.user_id = user_id
        self.priority = priority
        self.status = 'open'
    
    def close(self):
        """Close the ticket"""
        if self.status == 'closed':
            return False, 'Ticket is already closed'
        self.status = 'closed'
        self.closed_at = datetime.utcnow()
        return True, 'Ticket closed successfully'
    
    def reopen(self):
        """Reopen a closed ticket"""
        if self.status != 'closed':
            return False, 'Ticket is not closed'
        self.status = 'open'
        self.closed_at = None
        return True, 'Ticket reopened successfully'
    
    def add_reply(self, user_id, message, is_admin=False):
        """Add a reply to the ticket"""
        reply = TicketReply(
            ticket_id=self.id,
            user_id=user_id,
            message=message,
            is_admin=is_admin
        )
        db.session.add(reply)
        if self.status == 'closed':
            self.status = 'open'
        elif self.status == 'open':
            self.status = 'in_progress'
        return reply
    
    def to_dict(self):
        """Convert ticket object to dictionary"""
        return {
            'id': self.id,
            'subject': self.subject,
            'message': self.message,
            'status': self.status,
            'priority': self.priority,
            'user_id': self.user_id,
            'admin_id': self.admin_id,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'closed_at': self.closed_at.isoformat() if self.closed_at else None,
            'reply_count': len(self.replies)
        }
    
    def __repr__(self):
        return f'<Ticket {self.id}: {self.subject}>'

class TicketReply(db.Model):
    """Ticket reply model for support conversations"""
    __tablename__ = 'ticket_replies'
    
    id = db.Column(db.Integer, primary_key=True)
    ticket_id = db.Column(db.Integer, db.ForeignKey('tickets.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_admin = db.Column(db.Boolean, default=False)
    
    def __init__(self, ticket_id, user_id, message, is_admin=False):
        self.ticket_id = ticket_id
        self.user_id = user_id
        self.message = message
        self.is_admin = is_admin
    
    def to_dict(self):
        """Convert reply object to dictionary"""
        return {
            'id': self.id,
            'ticket_id': self.ticket_id,
            'user_id': self.user_id,
            'message': self.message,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'is_admin': self.is_admin
        }
    
    def __repr__(self):
        return f'<TicketReply {self.id}>'