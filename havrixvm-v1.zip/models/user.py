from flask_login import UserMixin
from datetime import datetime
import bcrypt
from database import db

class User(UserMixin, db.Model):
    """User model for authentication and management"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), default='user')  # user, admin
    is_active = db.Column(db.Boolean, default=True)
    is_verified = db.Column(db.Boolean, default=False)
    last_login = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    servers = db.relationship('Server', backref='owner', lazy=True, cascade='all, delete-orphan')
    tickets = db.relationship('Ticket', backref='creator', lazy=True, cascade='all, delete-orphan')
    
    def __init__(self, username, email, password, role='user', is_active=True, is_verified=False):
        self.username = username
        self.email = email
        self.password = password  # This will call the setter
        self.role = role
        self.is_active = is_active
        self.is_verified = is_verified
    
    @property
    def password(self):
        """Password getter - raises AttributeError to prevent access"""
        raise AttributeError('password is not a readable attribute')
    
    @password.setter
    def password(self, password):
        """Hash password before storing"""
        if password:
            salt = bcrypt.gensalt()
            self.password_hash = bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')
    
    def verify_password(self, password):
        """Verify if provided password matches stored hash"""
        if not password or not self.password_hash:
            return False
        return bcrypt.checkpw(password.encode('utf-8'), self.password_hash.encode('utf-8'))
    
    def change_password(self, old_password, new_password):
        """Change user password"""
        if not self.verify_password(old_password):
            return False, 'Current password is incorrect'
        if len(new_password) < 6:
            return False, 'New password must be at least 6 characters'
        self.password = new_password
        return True, 'Password changed successfully'
    
    def get_id(self):
        """Get user ID as string for Flask-Login"""
        return str(self.id)
    
    def is_admin(self):
        """Check if user has admin role"""
        return self.role == 'admin'
    
    def can_manage_server(self, server):
        """Check if user can manage a specific server"""
        if self.is_admin():
            return True
        return server.user_id == self.id
    
    def can_create_server(self):
        """Check if user can create new servers"""
        if not self.is_active:
            return False
        # Check max servers limit
        max_servers = 10  # Default max, can be made configurable
        return len(self.servers) < max_servers
    
    def to_dict(self):
        """Convert user object to dictionary"""
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'role': self.role,
            'is_active': self.is_active,
            'is_verified': self.is_verified,
            'last_login': self.last_login.isoformat() if self.last_login else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'server_count': len(self.servers)
        }
    
    def __repr__(self):
        return f'<User {self.username}>'