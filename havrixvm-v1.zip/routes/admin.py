from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from datetime import datetime
from database import db
from models.user import User
from models.server import Server
from models.ticket import Ticket
from models.setting import Setting

admin_bp = Blueprint('admin', __name__)

@admin_bp.before_request
@login_required
def admin_required():
    """Ensure only admins can access admin routes"""
    if not current_user.is_admin():
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('user.dashboard'))

@admin_bp.route('/')
def dashboard():
    """Admin dashboard with system statistics"""
    # User statistics
    total_users = User.query.count()
    active_users = User.query.filter_by(is_active=True).count()
    admin_users = User.query.filter_by(role='admin').count()
    
    # Server statistics
    total_servers = Server.query.count()
    running_servers = Server.query.filter_by(status='running').count()
    stopped_servers = Server.query.filter_by(status='stopped').count()
    suspended_servers = Server.query.filter_by(status='suspended').count()
    
    # Ticket statistics
    total_tickets = Ticket.query.count()
    open_tickets = Ticket.query.filter(Ticket.status != 'closed').count()
    closed_tickets = Ticket.query.filter_by(status='closed').count()
    
    # Recent activity
    recent_users = User.query.order_by(User.created_at.desc()).limit(5).all()
    recent_servers = Server.query.order_by(Server.created_at.desc()).limit(5).all()
    recent_tickets = Ticket.query.order_by(Ticket.created_at.desc()).limit(5).all()
    
    return render_template('admin.html',
                         total_users=total_users,
                         active_users=active_users,
                         admin_users=admin_users,
                         total_servers=total_servers,
                         running_servers=running_servers,
                         stopped_servers=stopped_servers,
                         suspended_servers=suspended_servers,
                         total_tickets=total_tickets,
                         open_tickets=open_tickets,
                         closed_tickets=closed_tickets,
                         recent_users=recent_users,
                         recent_servers=recent_servers,
                         recent_tickets=recent_tickets)

# ============ USER MANAGEMENT ============

@admin_bp.route('/users')
def list_users():
    """List all users"""
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template('admin_users.html', users=users)

@admin_bp.route('/users/create', methods=['GET', 'POST'])
def create_user():
    """Create a new user"""
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '').strip()
        role = request.form.get('role', 'user')
        
        if not username or not email or not password:
            flash('Please fill in all fields', 'danger')
            return render_template('admin_create_user.html')
        
        if len(username) < 3:
            flash('Username must be at least 3 characters', 'danger')
            return render_template('admin_create_user.html')
        
        if not '@' in email or not '.' in email:
            flash('Please enter a valid email address', 'danger')
            return render_template('admin_create_user.html')
        
        if len(password) < 6:
            flash('Password must be at least 6 characters', 'danger')
            return render_template('admin_create_user.html')
        
        if User.query.filter_by(username=username).first():
            flash('Username already taken', 'danger')
            return render_template('admin_create_user.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already registered', 'danger')
            return render_template('admin_create_user.html')
        
        user = User(
            username=username,
            email=email,
            password=password,
            role=role,
            is_active=True,
            is_verified=True
        )
        
        db.session.add(user)
        db.session.commit()
        
        flash(f'User "{username}" created successfully!', 'success')
        return redirect(url_for('admin.list_users'))
    
    return render_template('admin_create_user.html')

@admin_bp.route('/users/<int:user_id>/edit', methods=['GET', 'POST'])
def edit_user(user_id):
    """Edit user details"""
    user = User.query.get_or_404(user_id)
    
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        role = request.form.get('role', 'user')
        is_active = request.form.get('is_active') == 'yes'
        
        if not username or not email:
            flash('Please fill in all fields', 'danger')
            return render_template('admin_edit_user.html', user=user)
        
        if len(username) < 3:
            flash('Username must be at least 3 characters', 'danger')
            return render_template('admin_edit_user.html', user=user)
        
        if not '@' in email or not '.' in email:
            flash('Please enter a valid email address', 'danger')
            return render_template('admin_edit_user.html', user=user)
        
        # Check if username taken by other user
        existing_user = User.query.filter(User.username == username, User.id != user_id).first()
        if existing_user:
            flash('Username already taken', 'danger')
            return render_template('admin_edit_user.html', user=user)
        
        existing_user = User.query.filter(User.email == email, User.id != user_id).first()
        if existing_user:
            flash('Email already registered', 'danger')
            return render_template('admin_edit_user.html', user=user)
        
        user.username = username
        user.email = email
        user.role = role
        user.is_active = is_active
        
        # Update password if provided
        new_password = request.form.get('new_password', '').strip()
        if new_password:
            if len(new_password) < 6:
                flash('Password must be at least 6 characters', 'danger')
                return render_template('admin_edit_user.html', user=user)
            user.password = new_password
        
        db.session.commit()
        
        flash(f'User "{username}" updated successfully!', 'success')
        return redirect(url_for('admin.list_users'))
    
    return render_template('admin_edit_user.html', user=user)

@admin_bp.route('/users/<int:user_id>/delete', methods=['POST'])
def delete_user(user_id):
    """Delete a user"""
    user = User.query.get_or_404(user_id)
    
    # Prevent deleting self
    if user.id == current_user.id:
        return jsonify({'error': 'Cannot delete your own account'}), 400
    
    username = user.username
    
    # Delete user's servers first (cascade will handle)
    db.session.delete(user)
    db.session.commit()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True, 'message': f'User "{username}" deleted successfully'})
    
    flash(f'User "{username}" deleted successfully', 'success')
    return redirect(url_for('admin.list_users'))

@admin_bp.route('/users/<int:user_id>/suspend', methods=['POST'])
def suspend_user(user_id):
    """Suspend a user"""
    user = User.query.get_or_404(user_id)
    
    if user.id == current_user.id:
        return jsonify({'error': 'Cannot suspend your own account'}), 400
    
    user.is_active = False
    db.session.commit()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True, 'message': f'User "{user.username}" suspended'})
    
    flash(f'User "{user.username}" suspended', 'success')
    return redirect(url_for('admin.list_users'))

@admin_bp.route('/users/<int:user_id>/unsuspend', methods=['POST'])
def unsuspend_user(user_id):
    """Unsuspend a user"""
    user = User.query.get_or_404(user_id)
    
    user.is_active = True
    db.session.commit()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True, 'message': f'User "{user.username}" unsuspended'})
    
    flash(f'User "{user.username}" unsuspended', 'success')
    return redirect(url_for('admin.list_users'))

# ============ VPS MANAGEMENT ============

@admin_bp.route('/servers')
def list_servers():
    """List all VPS instances"""
    servers = Server.query.order_by(Server.created_at.desc()).all()
    return render_template('admin_servers.html', servers=servers)

@admin_bp.route('/servers/create', methods=['GET', 'POST'])
def admin_create_server():
    """Admin create a VPS for any user"""
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        user_id = int(request.form.get('user_id', 0))
        os_type = request.form.get('os_type', 'Ubuntu')
        os_version = request.form.get('os_version', '22.04')
        cpu_cores = int(request.form.get('cpu_cores', 1))
        ram_mb = int(request.form.get('ram_mb', 1024))
        disk_gb = int(request.form.get('disk_gb', 20))
        node = request.form.get('node', 'node1')
        
        if not name:
            flash('Please enter a server name', 'danger')
            return render_template('admin_create_server.html')
        
        user = User.query.get(user_id)
        if not user:
            flash('Please select a valid user', 'danger')
            return render_template('admin_create_server.html')
        
        server = Server(
            name=name,
            user_id=user_id,
            os_type=os_type,
            os_version=os_version,
            cpu_cores=cpu_cores,
            ram_mb=ram_mb,
            disk_gb=disk_gb,
            node=node
        )
        
        db.session.add(server)
        db.session.commit()
        
        flash(f'VPS "{name}" created for user "{user.username}"', 'success')
        return redirect(url_for('admin.list_servers'))
    
    users = User.query.order_by(User.username).all()
    return render_template('admin_create_server.html', users=users)

@admin_bp.route('/servers/<int:server_id>/edit', methods=['GET', 'POST'])
def admin_edit_server(server_id):
    """Admin edit VPS details"""
    server = Server.query.get_or_404(server_id)
    
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        cpu_cores = int(request.form.get('cpu_cores', 1))
        ram_mb = int(request.form.get('ram_mb', 1024))
        disk_gb = int(request.form.get('disk_gb', 20))
        node = request.form.get('node', 'node1')
        status = request.form.get('status', 'stopped')
        
        if not name:
            flash('Please enter a server name', 'danger')
            return render_template('admin_edit_server.html', server=server)
        
        server.name = name
        server.cpu_cores = cpu_cores
        server.ram_mb = ram_mb
        server.disk_gb = disk_gb
        server.node = node
        server.status = status
        
        db.session.commit()
        
        flash(f'VPS "{name}" updated successfully!', 'success')
        return redirect(url_for('admin.list_servers'))
    
    return render_template('admin_edit_server.html', server=server)

@admin_bp.route('/servers/<int:server_id>/delete', methods=['POST'])
def admin_delete_server(server_id):
    """Admin delete a VPS"""
    server = Server.query.get_or_404(server_id)
    name = server.name
    
    db.session.delete(server)
    db.session.commit()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True, 'message': f'VPS "{name}" deleted'})
    
    flash(f'VPS "{name}" deleted', 'success')
    return redirect(url_for('admin.list_servers'))

@admin_bp.route('/servers/<int:server_id>/suspend', methods=['POST'])
def admin_suspend_server(server_id):
    """Admin suspend a VPS"""
    server = Server.query.get_or_404(server_id)
    success, message = server.suspend()
    if success:
        db.session.commit()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': success, 'message': message})
    
    flash(message, 'success' if success else 'danger')
    return redirect(url_for('admin.list_servers'))

@admin_bp.route('/servers/<int:server_id>/unsuspend', methods=['POST'])
def admin_unsuspend_server(server_id):
    """Admin unsuspend a VPS"""
    server = Server.query.get_or_404(server_id)
    success, message = server.unsuspend()
    if success:
        db.session.commit()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': success, 'message': message})
    
    flash(message, 'success' if success else 'danger')
    return redirect(url_for('admin.list_servers'))

@admin_bp.route('/servers/<int:server_id>/start', methods=['POST'])
def admin_start_server(server_id):
    """Admin start a VPS"""
    server = Server.query.get_or_404(server_id)
    success, message = server.start()
    if success:
        db.session.commit()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': success, 'message': message, 'status': server.status})
    
    flash(message, 'success' if success else 'danger')
    return redirect(url_for('admin.list_servers'))

@admin_bp.route('/servers/<int:server_id>/stop', methods=['POST'])
def admin_stop_server(server_id):
    """Admin stop a VPS"""
    server = Server.query.get_or_404(server_id)
    success, message = server.stop()
    if success:
        db.session.commit()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': success, 'message': message, 'status': server.status})
    
    flash(message, 'success' if success else 'danger')
    return redirect(url_for('admin.list_servers'))

@admin_bp.route('/servers/<int:server_id>/restart', methods=['POST'])
def admin_restart_server(server_id):
    """Admin restart a VPS"""
    server = Server.query.get_or_404(server_id)
    success, message = server.restart()
    if success:
        db.session.commit()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': success, 'message': message, 'status': server.status})
    
    flash(message, 'success' if success else 'danger')
    return redirect(url_for('admin.list_servers'))

# ============ SYSTEM SETTINGS ============

@admin_bp.route('/settings', methods=['GET', 'POST'])
def settings():
    """System settings"""
    if request.method == 'POST':
        site_name = request.form.get('site_name', '').strip()
        site_url = request.form.get('site_url', '').strip()
        maintenance_mode = request.form.get('maintenance_mode') == 'yes'
        registration_enabled = request.form.get('registration_enabled') == 'yes'
        max_vps_per_user = request.form.get('max_vps_per_user', '10')
        
        # Update settings
        settings_data = {
            'site_name': site_name,
            'site_url': site_url,
            'maintenance_mode': str(maintenance_mode).lower(),
            'registration_enabled': str(registration_enabled).lower(),
            'max_vps_per_user': max_vps_per_user
        }
        
        for key, value in settings_data.items():
            setting = Setting.query.filter_by(key=key).first()
            if setting:
                setting.value = value
            else:
                setting = Setting(key=key, value=value)
                db.session.add(setting)
        
        db.session.commit()
        flash('Settings updated successfully!', 'success')
        return redirect(url_for('admin.settings'))
    
    # Get current settings
    settings = {}
    for key in ['site_name', 'site_url', 'maintenance_mode', 'registration_enabled', 'max_vps_per_user']:
        setting = Setting.query.filter_by(key=key).first()
        settings[key] = setting.value if setting else ''
    
    return render_template('admin_settings.html', settings=settings)

# ============ API ENDPOINTS ============

@admin_bp.route('/api/stats')
def api_stats():
    """API endpoint for admin statistics"""
    return jsonify({
        'users': {
            'total': User.query.count(),
            'active': User.query.filter_by(is_active=True).count(),
            'admin': User.query.filter_by(role='admin').count()
        },
        'servers': {
            'total': Server.query.count(),
            'running': Server.query.filter_by(status='running').count(),
            'stopped': Server.query.filter_by(status='stopped').count(),
            'suspended': Server.query.filter_by(status='suspended').count()
        },
        'tickets': {
            'total': Ticket.query.count(),
            'open': Ticket.query.filter(Ticket.status != 'closed').count(),
            'closed': Ticket.query.filter_by(status='closed').count()
        }
    })