from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, session
from flask_login import login_required, current_user
from datetime import datetime
from database import db
from models.server import Server
from models.user import User
import secrets

server_bp = Blueprint('server', __name__)

@server_bp.route('/')
@login_required
def list_servers():
    """List all servers for the current user"""
    if current_user.is_admin():
        servers = Server.query.order_by(Server.created_at.desc()).all()
    else:
        servers = Server.query.filter_by(user_id=current_user.id).order_by(Server.created_at.desc()).all()
    
    return render_template('servers.html', servers=servers)

@server_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create_server():
    """Create a new VPS server"""
    if not current_user.can_create_server():
        flash('You have reached the maximum number of servers allowed', 'warning')
        return redirect(url_for('server.list_servers'))
    
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        os_type = request.form.get('os_type', 'Ubuntu')
        os_version = request.form.get('os_version', '22.04')
        cpu_cores = int(request.form.get('cpu_cores', 1))
        ram_mb = int(request.form.get('ram_mb', 1024))
        disk_gb = int(request.form.get('disk_gb', 20))
        
        if not name:
            flash('Please enter a server name', 'danger')
            return render_template('create_server.html')
        
        # Create server
        server = Server(
            name=name,
            user_id=current_user.id,
            os_type=os_type,
            os_version=os_version,
            cpu_cores=cpu_cores,
            ram_mb=ram_mb,
            disk_gb=disk_gb,
            node='node1'
        )
        
        db.session.add(server)
        db.session.commit()
        
        flash(f'Server "{name}" created successfully!', 'success')
        return redirect(url_for('server.view_server', server_id=server.id))
    
    return render_template('create_server.html')

@server_bp.route('/<int:server_id>')
@login_required
def view_server(server_id):
    """View server details"""
    server = Server.query.get_or_404(server_id)
    
    if not current_user.can_manage_server(server):
        flash('You do not have permission to view this server', 'danger')
        return redirect(url_for('server.list_servers'))
    
    return render_template('server_manage.html', server=server)

@server_bp.route('/<int:server_id>/start', methods=['POST'])
@login_required
def start_server(server_id):
    """Start a VPS server"""
    server = Server.query.get_or_404(server_id)
    
    if not current_user.can_manage_server(server):
        return jsonify({'error': 'Permission denied'}), 403
    
    success, message = server.start()
    if success:
        db.session.commit()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': success, 'message': message, 'status': server.status})
    
    flash(message, 'success' if success else 'danger')
    return redirect(url_for('server.view_server', server_id=server.id))

@server_bp.route('/<int:server_id>/stop', methods=['POST'])
@login_required
def stop_server(server_id):
    """Stop a VPS server"""
    server = Server.query.get_or_404(server_id)
    
    if not current_user.can_manage_server(server):
        return jsonify({'error': 'Permission denied'}), 403
    
    success, message = server.stop()
    if success:
        db.session.commit()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': success, 'message': message, 'status': server.status})
    
    flash(message, 'success' if success else 'danger')
    return redirect(url_for('server.view_server', server_id=server.id))

@server_bp.route('/<int:server_id>/restart', methods=['POST'])
@login_required
def restart_server(server_id):
    """Restart a VPS server"""
    server = Server.query.get_or_404(server_id)
    
    if not current_user.can_manage_server(server):
        return jsonify({'error': 'Permission denied'}), 403
    
    success, message = server.restart()
    if success:
        db.session.commit()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': success, 'message': message, 'status': server.status})
    
    flash(message, 'success' if success else 'danger')
    return redirect(url_for('server.view_server', server_id=server.id))

@server_bp.route('/<int:server_id>/rebuild', methods=['POST'])
@login_required
def rebuild_server(server_id):
    """Rebuild a VPS server"""
    server = Server.query.get_or_404(server_id)
    
    if not current_user.can_manage_server(server):
        return jsonify({'error': 'Permission denied'}), 403
    
    success, message = server.rebuild()
    if success:
        db.session.commit()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': success, 'message': message, 'status': server.status})
    
    flash(message, 'success' if success else 'danger')
    return redirect(url_for('server.view_server', server_id=server.id))

@server_bp.route('/<int:server_id>/console')
@login_required
def console(server_id):
    """VPS Console page"""
    server = Server.query.get_or_404(server_id)
    
    if not current_user.can_manage_server(server):
        flash('You do not have permission to access this console', 'danger')
        return redirect(url_for('server.list_servers'))
    
    return render_template('console.html', server=server)

@server_bp.route('/<int:server_id>/sshx', methods=['POST'])
@login_required
def generate_sshx(server_id):
    """Generate SSHX session for VPS"""
    server = Server.query.get_or_404(server_id)
    
    if not current_user.can_manage_server(server):
        return jsonify({'error': 'Permission denied'}), 403
    
    sshx_link = server.generate_sshx_session()
    db.session.commit()
    
    return jsonify({
        'success': True,
        'sshx_link': sshx_link,
        'session_id': server.sshx_session_id
    })

@server_bp.route('/<int:server_id>/sshx/delete', methods=['POST'])
@login_required
def delete_sshx(server_id):
    """Delete SSHX session"""
    server = Server.query.get_or_404(server_id)
    
    if not current_user.can_manage_server(server):
        return jsonify({'error': 'Permission denied'}), 403
    
    server.sshx_session_id = None
    server.sshx_link = None
    server.sshx_created_at = None
    server.sshx_expires_at = None
    db.session.commit()
    
    return jsonify({'success': True, 'message': 'SSHX session deleted'})

@server_bp.route('/<int:server_id>/tmate', methods=['POST'])
@login_required
def generate_tmate(server_id):
    """Generate TMATE session for VPS"""
    server = Server.query.get_or_404(server_id)
    
    if not current_user.can_manage_server(server):
        return jsonify({'error': 'Permission denied'}), 403
    
    tmate_data = server.generate_tmate_session()
    db.session.commit()
    
    return jsonify({
        'success': True,
        'ssh_link': tmate_data['ssh_link'],
        'web_link': tmate_data['web_link'],
        'session_id': server.tmate_session_id
    })

@server_bp.route('/<int:server_id>/tmate/terminate', methods=['POST'])
@login_required
def terminate_tmate(server_id):
    """Terminate TMATE session"""
    server = Server.query.get_or_404(server_id)
    
    if not current_user.can_manage_server(server):
        return jsonify({'error': 'Permission denied'}), 403
    
    server.tmate_session_id = None
    server.tmate_ssh_link = None
    server.tmate_web_link = None
    server.tmate_created_at = None
    server.tmate_expires_at = None
    db.session.commit()
    
    return jsonify({'success': True, 'message': 'TMATE session terminated'})

@server_bp.route('/<int:server_id>/ssh/password', methods=['POST'])
@login_required
def regenerate_ssh_password(server_id):
    """Regenerate SSH password for VPS"""
    server = Server.query.get_or_404(server_id)
    
    if not current_user.can_manage_server(server):
        return jsonify({'error': 'Permission denied'}), 403
    
    new_password = server.generate_ssh_password()
    server.ssh_password = new_password
    db.session.commit()
    
    return jsonify({
        'success': True,
        'password': new_password,
        'message': 'SSH password regenerated successfully'
    })

@server_bp.route('/<int:server_id>/ssh/command')
@login_required
def get_ssh_command(server_id):
    """Get SSH command for VPS"""
    server = Server.query.get_or_404(server_id)
    
    if not current_user.can_manage_server(server):
        return jsonify({'error': 'Permission denied'}), 403
    
    return jsonify({
        'success': True,
        'command': server.get_ssh_command(),
        'host': server.ipv4,
        'port': server.ssh_port,
        'username': server.ssh_username
    })