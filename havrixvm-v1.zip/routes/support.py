from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from datetime import datetime
from database import db
from models.ticket import Ticket, TicketReply
from models.user import User

support_bp = Blueprint('support', __name__)

@support_bp.route('/')
@login_required
def list_tickets():
    """List all tickets for the current user"""
    if current_user.is_admin():
        tickets = Ticket.query.order_by(Ticket.created_at.desc()).all()
    else:
        tickets = Ticket.query.filter_by(user_id=current_user.id).order_by(Ticket.created_at.desc()).all()
    
    return render_template('support.html', tickets=tickets)

@support_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create_ticket():
    """Create a new support ticket"""
    if request.method == 'POST':
        subject = request.form.get('subject', '').strip()
        message = request.form.get('message', '').strip()
        priority = request.form.get('priority', 'medium')
        
        if not subject or not message:
            flash('Please fill in all fields', 'danger')
            return render_template('create_ticket.html')
        
        ticket = Ticket(
            subject=subject,
            message=message,
            user_id=current_user.id,
            priority=priority
        )
        
        db.session.add(ticket)
        db.session.commit()
        
        flash('Ticket created successfully!', 'success')
        return redirect(url_for('support.view_ticket', ticket_id=ticket.id))
    
    return render_template('create_ticket.html')

@support_bp.route('/<int:ticket_id>')
@login_required
def view_ticket(ticket_id):
    """View a specific ticket and its replies"""
    ticket = Ticket.query.get_or_404(ticket_id)
    
    # Check permission
    if not current_user.is_admin() and ticket.user_id != current_user.id:
        flash('You do not have permission to view this ticket', 'danger')
        return redirect(url_for('support.list_tickets'))
    
    # Get replies
    replies = TicketReply.query.filter_by(ticket_id=ticket.id).order_by(TicketReply.created_at.asc()).all()
    
    return render_template('view_ticket.html', ticket=ticket, replies=replies)

@support_bp.route('/<int:ticket_id>/reply', methods=['POST'])
@login_required
def reply_ticket(ticket_id):
    """Add a reply to a ticket"""
    ticket = Ticket.query.get_or_404(ticket_id)
    
    # Check permission
    if not current_user.is_admin() and ticket.user_id != current_user.id:
        return jsonify({'error': 'Permission denied'}), 403
    
    message = request.form.get('message', '').strip()
    
    if not message:
        flash('Please enter a message', 'danger')
        return redirect(url_for('support.view_ticket', ticket_id=ticket.id))
    
    is_admin = current_user.is_admin()
    
    reply = ticket.add_reply(current_user.id, message, is_admin)
    db.session.commit()
    
    flash('Reply added successfully', 'success')
    return redirect(url_for('support.view_ticket', ticket_id=ticket.id))

@support_bp.route('/<int:ticket_id>/close', methods=['POST'])
@login_required
def close_ticket(ticket_id):
    """Close a ticket"""
    ticket = Ticket.query.get_or_404(ticket_id)
    
    # Check permission
    if not current_user.is_admin() and ticket.user_id != current_user.id:
        return jsonify({'error': 'Permission denied'}), 403
    
    success, message = ticket.close()
    if success:
        db.session.commit()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': success, 'message': message})
    
    flash(message, 'success' if success else 'danger')
    return redirect(url_for('support.view_ticket', ticket_id=ticket.id))

@support_bp.route('/<int:ticket_id>/reopen', methods=['POST'])
@login_required
def reopen_ticket(ticket_id):
    """Reopen a closed ticket"""
    ticket = Ticket.query.get_or_404(ticket_id)
    
    # Check permission
    if not current_user.is_admin() and ticket.user_id != current_user.id:
        return jsonify({'error': 'Permission denied'}), 403
    
    success, message = ticket.reopen()
    if success:
        db.session.commit()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': success, 'message': message})
    
    flash(message, 'success' if success else 'danger')
    return redirect(url_for('support.view_ticket', ticket_id=ticket.id))

@support_bp.route('/api/tickets')
@login_required
def api_tickets():
    """API endpoint for tickets"""
    if current_user.is_admin():
        tickets = Ticket.query.order_by(Ticket.created_at.desc()).all()
    else:
        tickets = Ticket.query.filter_by(user_id=current_user.id).order_by(Ticket.created_at.desc()).all()
    
    return jsonify([t.to_dict() for t in tickets])