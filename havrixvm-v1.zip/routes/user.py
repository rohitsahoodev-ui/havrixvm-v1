from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from datetime import datetime, timedelta
from database import db
from models.user import User
from models.server import Server
from models.ticket import Ticket

user_bp = Blueprint('user', __name__)

@user_bp.route('/dashboard')
@login_required
def dashboard():
    """User dashboard showing VPS statistics and recent activity"""
    # Get user's servers
    servers = Server.query.filter_by(user_id=current_user.id).all()
    
    # Count by status
    total = len(servers)
    running = sum(1 for s in servers if s.status == 'running')
    stopped = sum(1 for s in servers if s.status == 'stopped')
    suspended = sum(1 for s in servers if s.status == 'suspended')
    
    # Get ticket count
    tickets = Ticket.query.filter_by(user_id=current_user.id).all()
    ticket_count = len(tickets)
    open_tickets = sum(1 for t in tickets if t.status != 'closed')
    
    # Recent activity (last 5 servers created)
    recent_servers = Server.query.filter_by(user_id=current_user.id)\
        .order_by(Server.created_at.desc()).limit(5).all()
    
    return render_template('dashboard.html',
                         total=total,
                         running=running,
                         stopped=stopped,
                         suspended=suspended,
                         ticket_count=ticket_count,
                         open_tickets=open_tickets,
                         recent_servers=recent_servers)

@user_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    """User profile page and update handler"""
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        
        # Validation
        if not username or not email:
            flash('Please fill in all fields', 'danger')
            return render_template('profile.html', user=current_user)
        
        if len(username) < 3:
            flash('Username must be at least 3 characters', 'danger')
            return render_template('profile.html', user=current_user)
        
        if not '@' in email or not '.' in email:
            flash('Please enter a valid email address', 'danger')
            return render_template('profile.html', user=current_user)
        
        # Check if username taken by other user
        existing_user = User.query.filter(User.username == username, User.id != current_user.id).first()
        if existing_user:
            flash('Username already taken', 'danger')
            return render_template('profile.html', user=current_user)
        
        # Check if email taken by other user
        existing_user = User.query.filter(User.email == email, User.id != current_user.id).first()
        if existing_user:
            flash('Email already registered', 'danger')
            return render_template('profile.html', user=current_user)
        
        # Update user
        current_user.username = username
        current_user.email = email
        db.session.commit()
        
        flash('Profile updated successfully', 'success')
        return redirect(url_for('user.profile'))
    
    return render_template('profile.html', user=current_user)

@user_bp.route('/change-password', methods=['GET', 'POST'])
@login_required
def change_password():
    """Change password page and handler"""
    if request.method == 'POST':
        current_password = request.form.get('current_password', '').strip()
        new_password = request.form.get('new_password', '').strip()
        confirm_password = request.form.get('confirm_password', '').strip()
        
        if not current_password or not new_password:
            flash('Please fill in all fields', 'danger')
            return render_template('change_password.html')
        
        if len(new_password) < 6:
            flash('New password must be at least 6 characters', 'danger')
            return render_template('change_password.html')
        
        if new_password != confirm_password:
            flash('Passwords do not match', 'danger')
            return render_template('change_password.html')
        
        # Verify current password
        if not current_user.verify_password(current_password):
            flash('Current password is incorrect', 'danger')
            return render_template('change_password.html')
        
        # Update password
        current_user.password = new_password
        db.session.commit()
        
        flash('Password changed successfully', 'success')
        return redirect(url_for('user.dashboard'))
    
    return render_template('change_password.html')

@user_bp.route('/api/profile')
@login_required
def api_profile():
    """API endpoint for user profile data"""
    return jsonify(current_user.to_dict())