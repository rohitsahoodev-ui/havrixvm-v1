/* ============================================
   Havrix VM - Main JavaScript
   Version: 1.0.0
   ============================================ */

// ===== Utility Functions =====

/**
 * Get CSRF token from meta tag
 */
function getCsrfToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    return meta ? meta.getAttribute('content') : '';
}

/**
 * Show notification toast
 */
function showNotification(message, type = 'info') {
    const colors = {
        success: '#22C55E',
        danger: '#EF4444',
        warning: '#F59E0B',
        info: '#3B82F6'
    };
    
    const toast = document.createElement('div');
    toast.style.cssText = `
        position: fixed;
        top: 80px;
        right: 20px;
        padding: 12px 20px;
        background: white;
        border-left: 4px solid ${colors[type] || colors.info};
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 9999;
        max-width: 400px;
        font-size: 14px;
        color: #1E293B;
        transform: translateX(120%);
        transition: transform 0.3s ease;
    `;
    toast.innerHTML = message;
    document.body.appendChild(toast);
    
    // Show
    setTimeout(() => {
        toast.style.transform = 'translateX(0)';
    }, 100);
    
    // Hide after 5 seconds
    setTimeout(() => {
        toast.style.transform = 'translateX(120%)';
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, 5000);
}

/**
 * Format date
 */
function formatDate(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

/**
 * Format bytes to human readable
 */
function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// ===== Server Actions =====

/**
 * Execute server action (start, stop, restart, rebuild)
 */
function serverAction(serverId, action) {
    const button = document.querySelector(`#action-${action}-${serverId}`);
    const originalText = button ? button.innerHTML : '';
    
    if (button) {
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
    }
    
    fetch(`/server/${serverId}/${action}`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-Token': getCsrfToken()
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification(data.message, 'success');
            // Update status badge
            const statusBadge = document.querySelector(`#status-${serverId}`);
            if (statusBadge && data.status) {
                statusBadge.textContent = data.status;
                statusBadge.className = `badge badge-${getStatusClass(data.status)}`;
            }
            // Reload page after short delay if needed
            if (action === 'rebuild') {
                setTimeout(() => window.location.reload(), 2000);
            }
        } else {
            showNotification(data.message || 'Action failed', 'danger');
        }
    })
    .catch(error => {
        showNotification('An error occurred. Please try again.', 'danger');
    })
    .finally(() => {
        if (button) {
            button.disabled = false;
            button.innerHTML = originalText;
        }
    });
}

/**
 * Get status CSS class
 */
function getStatusClass(status) {
    const classes = {
        'running': 'success',
        'stopped': 'secondary',
        'suspended': 'warning',
        'creating': 'info',
        'deleting': 'danger',
        'rebuilding': 'warning'
    };
    return classes[status] || 'secondary';
}

// ===== SSH Functions =====

/**
 * Copy SSH command to clipboard
 */
function copySSHCommand(serverId) {
    fetch(`/server/${serverId}/ssh/command`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                navigator.clipboard.writeText(data.command)
                    .then(() => {
                        showNotification('SSH command copied to clipboard!', 'success');
                    })
                    .catch(() => {
                        // Fallback
                        const textarea = document.createElement('textarea');
                        textarea.value = data.command;
                        document.body.appendChild(textarea);
                        textarea.select();
                        document.execCommand('copy');
                        textarea.remove();
                        showNotification('SSH command copied to clipboard!', 'success');
                    });
            }
        })
        .catch(() => {
            showNotification('Failed to get SSH command', 'danger');
        });
}

/**
 * Regenerate SSH password
 */
function regenerateSSHPassword(serverId) {
    if (!confirm('Are you sure you want to regenerate the SSH password?')) return;
    
    const button = document.querySelector('#regenerate-ssh');
    const originalText = button ? button.innerHTML : '';
    
    if (button) {
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
    }
    
    fetch(`/server/${serverId}/ssh/password`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-Token': getCsrfToken()
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const passwordElement = document.querySelector('#ssh-password');
            if (passwordElement) {
                passwordElement.textContent = data.password;
            }
            showNotification('SSH password regenerated successfully!', 'success');
        } else {
            showNotification(data.message || 'Failed to regenerate password', 'danger');
        }
    })
    .catch(() => {
        showNotification('An error occurred. Please try again.', 'danger');
    })
    .finally(() => {
        if (button) {
            button.disabled = false;
            button.innerHTML = originalText;
        }
    });
}

// ===== SSHX Functions =====

/**
 * Generate SSHX session
 */
function generateSSHX(serverId) {
    const button = document.querySelector('#generate-sshx');
    const originalText = button ? button.innerHTML : '';
    
    if (button) {
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
    }
    
    fetch(`/server/${serverId}/sshx`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-Token': getCsrfToken()
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const container = document.querySelector('#sshx-container');
            if (container) {
                container.innerHTML = `
                    <div class="sshx-session">
                        <p><strong>SSHX Link:</strong></p>
                        <div class="input-group">
                            <input type="text" class="form-control" value="${data.sshx_link}" readonly>
                            <button class="btn btn-primary btn-sm" onclick="copyToClipboard('${data.sshx_link}')">
                                <i class="fas fa-copy"></i>
                            </button>
                            <button class="btn btn-danger btn-sm" onclick="deleteSSHX(${serverId})">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                        <small class="text-muted">Session ID: ${data.session_id}</small>
                    </div>
                `;
            }
            showNotification('SSHX session generated!', 'success');
        } else {
            showNotification(data.message || 'Failed to generate SSHX session', 'danger');
        }
    })
    .catch(() => {
        showNotification('An error occurred. Please try again.', 'danger');
    })
    .finally(() => {
        if (button) {
            button.disabled = false;
            button.innerHTML = originalText;
        }
    });
}

/**
 * Delete SSHX session
 */
function deleteSSHX(serverId) {
    if (!confirm('Are you sure you want to delete this SSHX session?')) return;
    
    fetch(`/server/${serverId}/sshx/delete`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-Token': getCsrfToken()
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const container = document.querySelector('#sshx-container');
            if (container) {
                container.innerHTML = `
                    <button class="btn btn-primary" onclick="generateSSHX(${serverId})">
                        <i class="fas fa-link"></i> Generate SSHX Session
                    </button>
                `;
            }
            showNotification('SSHX session deleted', 'success');
        }
    })
    .catch(() => {
        showNotification('An error occurred. Please try again.', 'danger');
    });
}

// ===== TMATE Functions =====

/**
 * Generate TMATE session
 */
function generateTMATE(serverId) {
    const button = document.querySelector('#generate-tmate');
    const originalText = button ? button.innerHTML : '';
    
    if (button) {
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
    }
    
    fetch(`/server/${serverId}/tmate`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-Token': getCsrfToken()
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const container = document.querySelector('#tmate-container');
            if (container) {
                container.innerHTML = `
                    <div class="tmate-session">
                        <p><strong>TMATE SSH Link:</strong></p>
                        <div class="input-group">
                            <input type="text" class="form-control" value="${data.ssh_link}" readonly>
                            <button class="btn btn-primary btn-sm" onclick="copyToClipboard('${data.ssh_link}')">
                                <i class="fas fa-copy"></i>
                            </button>
                        </div>
                        <p class="mt-2"><strong>TMATE Web Link:</strong></p>
                        <div class="input-group">
                            <input type="text" class="form-control" value="${data.web_link}" readonly>
                            <button class="btn btn-primary btn-sm" onclick="copyToClipboard('${data.web_link}')">
                                <i class="fas fa-copy"></i>
                            </button>
                            <a href="${data.web_link}" target="_blank" class="btn btn-success btn-sm">
                                <i class="fas fa-external-link-alt"></i> Open
                            </a>
                            <button class="btn btn-danger btn-sm" onclick="terminateTMATE(${serverId})">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <small class="text-muted">Session ID: ${data.session_id}</small>
                    </div>
                `;
            }
            showNotification('TMATE session generated!', 'success');
        } else {
            showNotification(data.message || 'Failed to generate TMATE session', 'danger');
        }
    })
    .catch(() => {
        showNotification('An error occurred. Please try again.', 'danger');
    })
    .finally(() => {
        if (button) {
            button.disabled = false;
            button.innerHTML = originalText;
        }
    });
}

/**
 * Terminate TMATE session
 */
function terminateTMATE(serverId) {
    if (!confirm('Are you sure you want to terminate this TMATE session?')) return;
    
    fetch(`/server/${serverId}/tmate/terminate`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-Token': getCsrfToken()
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const container = document.querySelector('#tmate-container');
            if (container) {
                container.innerHTML = `
                    <button class="btn btn-primary" onclick="generateTMATE(${serverId})">
                        <i class="fas fa-link"></i> Generate TMATE Session
                    </button>
                `;
            }
            showNotification('TMATE session terminated', 'success');
        }
    })
    .catch(() => {
        showNotification('An error occurred. Please try again.', 'danger');
    });
}

// ===== Clipboard Functions =====

/**
 * Copy text to clipboard
 */
function copyToClipboard(text) {
    if (!text) return;
    
    navigator.clipboard.writeText(text)
        .then(() => {
            showNotification('Copied to clipboard!', 'success');
        })
        .catch(() => {
            // Fallback
            const textarea = document.createElement('textarea');
            textarea.value = text;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            textarea.remove();
            showNotification('Copied to clipboard!', 'success');
        });
}

// ===== Console Functions =====

/**
 * Initialize console
 */
function initConsole(serverId) {
    const consoleBody = document.querySelector('#console-body');
    const inputField = document.querySelector('#console-input');
    const statusDot = document.querySelector('#console-status .dot');
    const statusText = document.querySelector('#console-status .status-text');
    
    if (!consoleBody || !inputField) return;
    
    let ws = null;
    let isConnected = false;
    
    // Connect to WebSocket (simulated)
    function connectConsole() {
        // This is a simulated connection
        // In production, this would connect to a real WebSocket
        isConnected = true;
        if (statusDot) statusDot.className = 'dot connected';
        if (statusText) statusText.textContent = 'Connected';
        showNotification('Console connected', 'success');
        consoleBody.innerHTML += '<div class="line">[System] Console session started</div>';
        consoleBody.scrollTop = consoleBody.scrollHeight;
    }
    
    // Disconnect
    function disconnectConsole() {
        isConnected = false;
        if (statusDot) statusDot.className = 'dot disconnected';
        if (statusText) statusText.textContent = 'Disconnected';
        showNotification('Console disconnected', 'warning');
    }
    
    // Send command
    function sendCommand(command) {
        if (!isConnected) {
            showNotification('Console is not connected', 'warning');
            return;
        }
        
        // Display command
        consoleBody.innerHTML += `<div class="line input-line">
            <span class="prompt">$</span>
            <span>${command}</span>
        </div>`;
        
        // Simulate response
        setTimeout(() => {
            consoleBody.innerHTML += `<div class="line">[System] Command executed: ${command}</div>`;
            consoleBody.scrollTop = consoleBody.scrollHeight;
        }, 300);
    }
    
    // Connect on load
    connectConsole();
    
    // Input handler
    inputField.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            const command = this.value.trim();
            if (command) {
                sendCommand(command);
                this.value = '';
            }
        }
    });
    
    // Fullscreen
    document.querySelector('#console-fullscreen')?.addEventListener('click', function() {
        const container = document.querySelector('.console-container');
        if (container) {
            if (!document.fullscreenElement) {
                container.requestFullscreen().catch(() => {});
            } else {
                document.exitFullscreen();
            }
        }
    });
    
    // Clear console
    document.querySelector('#console-clear')?.addEventListener('click', function() {
        consoleBody.innerHTML = '';
        consoleBody.innerHTML += '<div class="line">[System] Console cleared</div>';
    });
}

// ===== Ticket Functions =====

/**
 * Close ticket
 */
function closeTicket(ticketId) {
    if (!confirm('Are you sure you want to close this ticket?')) return;
    
    fetch(`/support/${ticketId}/close`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-Token': getCsrfToken()
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const statusBadge = document.querySelector('#ticket-status');
            if (statusBadge) {
                statusBadge.textContent = 'Closed';
                statusBadge.className = 'badge badge-secondary';
            }
            document.querySelector('#close-ticket-btn')?.remove();
            showNotification('Ticket closed successfully', 'success');
        } else {
            showNotification(data.message || 'Failed to close ticket', 'danger');
        }
    })
    .catch(() => {
        showNotification('An error occurred. Please try again.', 'danger');
    });
}

/**
 * Reopen ticket
 */
function reopenTicket(ticketId) {
    fetch(`/support/${ticketId}/reopen`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-Token': getCsrfToken()
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const statusBadge = document.querySelector('#ticket-status');
            if (statusBadge) {
                statusBadge.textContent = 'Open';
                statusBadge.className = 'badge badge-info';
            }
            showNotification('Ticket reopened successfully', 'success');
            setTimeout(() => window.location.reload(), 1000);
        } else {
            showNotification(data.message || 'Failed to reopen ticket', 'danger');
        }
    })
    .catch(() => {
        showNotification('An error occurred. Please try again.', 'danger');
    });
}

// ===== User Management (Admin) =====

/**
 * Delete user
 */
function deleteUser(userId, username) {
    if (!confirm(`Are you sure you want to delete user "${username}"? This action cannot be undone.`)) return;
    
    fetch(`/admin/users/${userId}/delete`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-Token': getCsrfToken()
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification(data.message, 'success');
            setTimeout(() => window.location.reload(), 1000);
        } else {
            showNotification(data.message || 'Failed to delete user', 'danger');
        }
    })
    .catch(() => {
        showNotification('An error occurred. Please try again.', 'danger');
    });
}

/**
 * Suspend user
 */
function suspendUser(userId, username) {
    if (!confirm(`Are you sure you want to suspend user "${username}"?`)) return;
    
    fetch(`/admin/users/${userId}/suspend`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-Token': getCsrfToken()
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification(data.message, 'success');
            setTimeout(() => window.location.reload(), 500);
        } else {
            showNotification(data.message || 'Failed to suspend user', 'danger');
        }
    })
    .catch(() => {
        showNotification('An error occurred. Please try again.', 'danger');
    });
}

/**
 * Unsuspend user
 */
function unsuspendUser(userId, username) {
    fetch(`/admin/users/${userId}/unsuspend`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-Token': getCsrfToken()
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification(data.message, 'success');
            setTimeout(() => window.location.reload(), 500);
        } else {
            showNotification(data.message || 'Failed to unsuspend user', 'danger');
        }
    })
    .catch(() => {
        showNotification('An error occurred. Please try again.', 'danger');
    });
}

// ===== VPS Management (Admin) =====

/**
 * Delete VPS (Admin)
 */
function adminDeleteServer(serverId, name) {
    if (!confirm(`Are you sure you want to delete VPS "${name}"? This action cannot be undone.`)) return;
    
    fetch(`/admin/servers/${serverId}/delete`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-Token': getCsrfToken()
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification(data.message, 'success');
            setTimeout(() => window.location.reload(), 1000);
        } else {
            showNotification(data.message || 'Failed to delete VPS', 'danger');
        }
    })
    .catch(() => {
        showNotification('An error occurred. Please try again.', 'danger');
    });
}

// ===== Confirm Dialog =====

/**
 * Show confirm dialog
 */
function showConfirm(message, callback) {
    if (confirm(message)) {
        callback();
    }
}

// ===== Auto-init =====

document.addEventListener('DOMContentLoaded', function() {
    // Initialize console if present
    const consoleContainer = document.querySelector('#console-body');
    if (consoleContainer) {
        const serverId = consoleContainer.dataset.serverId;
        if (serverId) {
            initConsole(serverId);
        }
    }
    
    // Auto-dismiss alerts after 5 seconds
    document.querySelectorAll('.alert').forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s ease';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 5000);
    });
});